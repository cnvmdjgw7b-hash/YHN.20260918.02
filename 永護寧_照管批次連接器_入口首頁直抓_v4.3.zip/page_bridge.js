(() => {
  if (window.__YHN_BATCH_V43_BRIDGE__) return;
  window.__YHN_BATCH_V43_BRIDGE__ = true;

  const CODE_RE = /\b(?:BA\d{2}(?:-\d+|[a-zA-Z])?|GA\d{2}(?:-\d+)?|SC\d{2}(?:-\d+)?)\b/g;
  const ROC_DATE_RE = /\b1\d{2}[\/.-](?:0?[1-9]|1[0-2])[\/.-](?:0?[1-9]|[12]\d|3[01])\b/g;
  const uniq = (a,l=100)=>[...new Set(a)].slice(0,l);
  const clean = s=>String(s||"").replace(/\s+/g," ").trim();

  function emit(requestId, stage, payload={}) {
    window.postMessage({__YHN_BATCH_V43_BRIDGE__:true, requestId, stage, payload},"*");
  }

  async function fetchText(url, opts={}) {
    const r=await fetch(url,{credentials:"include",cache:"no-store",...opts});
    const text=await r.text();
    if(!r.ok) throw new Error(`HTTP_${r.status}`);
    if(/請輸入帳號|帳號密碼登入/i.test(text)) throw new Error("SESSION_NOT_READY");
    return {text,r};
  }

  async function fetchJson(url, opts={}) {
    const {text}=await fetchText(url,opts);
    try{return JSON.parse(text)}catch(_){throw new Error("JSON_PARSE_FAILED")}
  }

  function recursiveFind(obj,keyRe,depth=0){
    if(depth>7||obj==null)return null;
    if(Array.isArray(obj)){
      for(const x of obj){const v=recursiveFind(x,keyRe,depth+1);if(v!=null)return v}
      return null;
    }
    if(typeof obj==="object"){
      for(const [k,v] of Object.entries(obj)){
        if(keyRe.test(k)&&(typeof v==="string"||typeof v==="number"))return v;
      }
      for(const v of Object.values(obj)){
        const x=recursiveFind(v,keyRe,depth+1);
        if(x!=null)return x;
      }
    }
    return null;
  }

  function allValues(obj,out=[],depth=0){
    if(depth>7||obj==null||out.length>2000)return out;
    if(typeof obj==="string"||typeof obj==="number"){out.push(String(obj));return out}
    if(Array.isArray(obj)){for(const x of obj)allValues(x,out,depth+1);return out}
    if(typeof obj==="object"){
      for(const [k,v] of Object.entries(obj)){out.push(k);allValues(v,out,depth+1)}
    }
    return out;
  }

  async function verifyCa100Id(id){
    if(!/^\d{8,12}$/.test(String(id||"")))return false;
    try{
      const h=(await fetchText(`/lcms/ca/showCaseDetail/${encodeURIComponent(id)}`)).text;
      return /照顧計畫|申報紀錄|異動通報/.test(h)&&!/查無資料|not found/i.test(h);
    }catch(_){return false}
  }

  async function deriveCa100Id(row){
    const direct=recursiveFind(row,/^ca100id$|^ca100.*id$/i);
    if(direct!=null&&await verifyCa100Id(direct))return String(direct);

    const vals=allValues(row),joined=vals.join(" ");
    const explicit=[];
    for(const re of [
      /showCaseDetail(?:\/|%2F)(\d{8,12})/ig,
      /CA100-LIST30(?:-2)?-(\d{8,12})/ig,
      /QD-LIST1(?:-2)?-(\d{8,12})/ig
    ]) for(const m of joined.matchAll(re))explicit.push(m[1]);

    for(const id of [...new Set(explicit)]){
      if(await verifyCa100Id(id))return id;
    }

    const nums=[...new Set(vals.flatMap(v=>String(v).match(/\b\d{8,12}\b/g)||[]))].slice(0,100);
    nums.sort((a,b)=>(a.length===10?0:1)-(b.length===10?0:1));
    for(const id of nums){
      if(await verifyCa100Id(id))return id;
    }
    return null;
  }

  async function findCaseDirect(idno){
    idno=String(idno||"").trim().toUpperCase().replace(/\s+/g,"");
    if(!/^[A-Z][0-9]{9}$/.test(idno))throw new Error("INVALID_IDNO");

    const paths=["/lcms/ca/filter","/lcms/ca/filter/"];
    let lastErr=null;

    for(const path of paths){
      try{
        const u=new URL(path,location.origin);
        u.searchParams.set("doQuery","true");
        u.searchParams.set("idno",idno);
        u.searchParams.set("offset","0");
        u.searchParams.set("limit","20");
        u.searchParams.set("_",String(Date.now()));

        const j=await fetchJson(u.href,{
          headers:{
            "Accept":"application/json, text/javascript, */*; q=0.01",
            "X-Requested-With":"XMLHttpRequest"
          }
        });
        const rows=Array.isArray(j?.rows)?j.rows:[];
        const total=Number(j?.total??rows.length);

        if(rows.length===0)throw new Error("OFFICIAL_QUERY_NO_ROWS");
        if(rows.length!==1)throw new Error("OFFICIAL_QUERY_MULTIPLE_ROWS");

        const ca100id=await deriveCa100Id(rows[0]);
        if(!ca100id)throw new Error("CA100ID_NOT_FOUND_IN_OFFICIAL_ROW");

        return {ca100id,total,rows:rows.length,mode:"direct-filter"};
      }catch(e){
        lastErr=e;
        const msg=String(e?.message||e);
        if(/OFFICIAL_QUERY_NO_ROWS|OFFICIAL_QUERY_MULTIPLE_ROWS/.test(msg))throw e;
      }
    }
    throw lastErr||new Error("DIRECT_CS100_QUERY_FAILED");
  }

  function parsePlanTable(html){
    const doc=new DOMParser().parseFromString(html,"text/html");
    const out=[],seen=new Set();

    for(const tr of doc.querySelectorAll("tr")){
      const cells=[...tr.querySelectorAll("th,td")].map(x=>clean(x.textContent)).filter(Boolean);
      if(cells.length<4)continue;

      const codes=uniq(cells.join(" | ").match(CODE_RE)||[]);
      if(codes.length!==1)continue;

      const code=codes[0], idx=cells.findIndex(c=>c.includes(code));
      if(idx<0)continue;

      const codeCell=cells[idx];
      const name=codeCell.match(/\[(.*?)\]/)?.[1]||codeCell.replace(code,"").trim();
      const after=cells.slice(idx+1);
      const unitPrice=after.find(v=>/元/.test(v))||null;
      const approvedQty=after.find(v=>/^\d+(?:\s*\([^)]*\))?$/.test(v))||null;
      const subtotal=[...after].reverse().find(v=>/^\d+(?:\.\d+)?$/.test(v))||null;

      if(!approvedQty)continue;

      const key=`${code}|${approvedQty}|${unitPrice}|${subtotal}`;
      if(seen.has(key))continue;
      seen.add(key);
      out.push({code,name,unitPrice,approvedQty,subtotal});
    }
    return out;
  }

  function extractPlanCandidates(html){
    const doc=new DOMParser().parseFromString(html,"text/html");
    const out=[];

    for(const el of doc.querySelectorAll("a[href],button[onclick],input[onclick]")){
      const raw=el.getAttribute("href")||el.getAttribute("onclick")||"";
      const m=
        raw.match(/showPrintByBrowser\?ca110id=(\d{6,})/i) ||
        raw.match(/showCa110\/(\d{6,})/i) ||
        raw.match(/CA100-EDIT-CA110-(\d{6,})/i);
      if(!m)continue;
      const rowText=clean(el.closest("tr")?.innerText||"");
      out.push({id:m[1],dates:rowText.match(ROC_DATE_RE)||[]});
    }

    if(!out.length){
      for(const re of [
        /showPrintByBrowser\?ca110id=(\d{6,})/ig,
        /showCa110\/(\d{6,})/ig,
        /CA100-EDIT-CA110-(\d{6,})/ig
      ]) for(const m of html.matchAll(re)) out.push({id:m[1],dates:[]});
    }
    return out;
  }

  function rocNum(s){
    const m=String(s||"").match(/^(\d{3})[\/.-](\d{1,2})[\/.-](\d{1,2})$/);
    return m ? Number(m[1])*10000+Number(m[2])*100+Number(m[3]) : 0;
  }

  async function fetchLatestPlan(ca100id){
    let items=[];
    try{
      items.push(...extractPlanCandidates((await fetchText(`/lcms/ca/showCompareCa110List?ca100id=${encodeURIComponent(ca100id)}`)).text));
    }catch(_){}
    try{
      items.push(...extractPlanCandidates((await fetchText(`/lcms/ca/showCaseDetail/${encodeURIComponent(ca100id)}`)).text));
    }catch(_){}

    const map=new Map();
    for(const x of items){
      if(!map.has(x.id))map.set(x.id,{...x});
      else map.get(x.id).dates=uniq([...(map.get(x.id).dates||[]),...(x.dates||[])],20);
    }
    items=[...map.values()];
    if(!items.length)throw new Error("CARE_PLAN_ID_NOT_FOUND");

    items.sort((a,b)=>{
      const da=Math.max(0,...(a.dates||[]).map(rocNum));
      const db=Math.max(0,...(b.dates||[]).map(rocNum));
      return db!==da ? db-da : Number(b.id)-Number(a.id);
    });

    for(const x of items.slice(0,12)){
      try{
        const html=(await fetchText(`/lcms/ca/showPrintByBrowser?ca110id=${encodeURIComponent(x.id)}`)).text;
        const services=parsePlanTable(html);
        if(services.length)return {planId:x.id,services};
      }catch(_){}
    }
    throw new Error("CARE_PLAN_PARSE_FAILED");
  }

  function flatten(obj,out=[],depth=0){
    if(depth>5||out.length>1000||obj==null)return out;
    if(typeof obj==="string"||typeof obj==="number"){out.push(String(obj));return out}
    if(Array.isArray(obj)){for(const x of obj)flatten(x,out,depth+1);return out}
    if(typeof obj==="object")for(const x of Object.values(obj))flatten(x,out,depth+1);
    return out;
  }

  function summarizeRows(rows){
    const byCode={},dates=[];
    for(const row of rows||[]){
      const text=flatten(row).join(" ");
      for(const c of uniq(text.match(CODE_RE)||[]))byCode[c]=(byCode[c]||0)+1;
      for(const d of uniq(text.match(ROC_DATE_RE)||[]))dates.push(d);
    }
    return {rows:(rows||[]).length,byCode,dates:uniq(dates,50)};
  }

  function monthInfo(ym){
    const [y,m]=ym.split("-").map(Number);
    const ry=y-1911,mm=String(m).padStart(2,"0"),last=new Date(y,m,0).getDate();
    return {yyyymm:`${ry}${mm}`,start:`${ry}/${mm}/01`,end:`${ry}/${mm}/${String(last).padStart(2,"0")}`};
  }

  async function fetchRecords(ca100id,mi){
    let lastErr=null;
    for(const path of [`/lcms/qd/filterQd120A/${encodeURIComponent(ca100id)}`,"/lcms/qd/filterQd120A"]){
      try{
        const u=new URL(path,location.origin);
        u.searchParams.set("doQuery","true");
        u.searchParams.set("ca100id",ca100id);
        u.searchParams.set("servDt1",mi.start);
        u.searchParams.set("servDt2",mi.end);
        u.searchParams.set("offset","0");
        u.searchParams.set("limit","500");
        u.searchParams.set("_",String(Date.now()));
        const j=await fetchJson(u.href);
        return summarizeRows(Array.isArray(j?.rows)?j.rows:[]);
      }catch(e){lastErr=e}
    }
    throw lastErr||new Error("SERVICE_RECORD_FETCH_FAILED");
  }

  function parseTables(html){
    const doc=new DOMParser().parseFromString(html,"text/html"),out=[];
    for(const table of doc.querySelectorAll("table")){
      const rows=[];
      for(const tr of table.querySelectorAll("tr")){
        const cells=[...tr.querySelectorAll("th,td")].map(x=>clean(x.textContent)).filter(Boolean);
        if(cells.length)rows.push(cells.slice(0,12));
      }
      if(rows.length)out.push(rows);
    }
    return out.slice(0,8);
  }

  async function fetchBalance(ca100id,mi){
    try{
      const start=(await fetchText(`/lcms/qp/showPi400Balance?type=A&ca100id=${encodeURIComponent(ca100id)}`)).text;
      const doc=new DOMParser().parseFromString(start,"text/html");
      const form=doc.querySelector("form"),body=new URLSearchParams();

      if(form){
        for(const el of form.querySelectorAll("input[name],select[name],textarea[name]")){
          const n=el.getAttribute("name");
          if(n)body.set(n,el.value||el.getAttribute("value")||"");
        }
      }
      body.set("qca100id",ca100id);
      body.set("qyyymm",mi.yyyymm);
      body.set("h_qyyymm",mi.yyyymm);

      const action=form?.getAttribute("action")||"/lcms/qp/searchPi400Balance";
      const html=(await fetchText(action,{
        method:"POST",
        headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"},
        body
      })).text;

      return {ok:true,tables:parseTables(html)};
    }catch(e){
      return {ok:false,reason:String(e?.message||e)}
    }
  }

  async function run(requestId,{ca100id,month}){
    const diag={month,stages:["case-ok"]};
    try{
      emit(requestId,"progress",{text:"讀取最新照顧計畫…"});
      const plan=await fetchLatestPlan(ca100id);
      diag.planId=plan.planId;diag.stages.push("plan-ok");

      const mi=monthInfo(month);

      emit(requestId,"progress",{text:"讀取當月服務紀錄…"});
      const serviceRecords=await fetchRecords(ca100id,mi);
      diag.stages.push("records-ok");

      emit(requestId,"progress",{text:"讀取個人額度…"});
      const balance=await fetchBalance(ca100id,mi);
      diag.stages.push(balance.ok?"balance-ok":"balance-failed");

      emit(requestId,"done",{month,plan,serviceRecords,balance,diag});
    }catch(e){
      diag.error=String(e?.message||e);
      emit(requestId,"error",{message:diag.error,diag});
    }
  }

  window.addEventListener("message",ev=>{
    const d=ev.data;
    if(!d?.__YHN_BATCH_V43_BRIDGE__)return;

    if(d.type==="FIND_CASE"){
      (async()=>{
        try{
          const result=await findCaseDirect(d.payload?.idno);
          emit(d.requestId,"caseDone",result);
        }catch(e){
          emit(d.requestId,"caseError",{message:String(e?.message||e)});
        }
      })();
      return;
    }

    if(d.type==="FETCH_DATA"){
      run(d.requestId,d.payload||{});
    }
  });
})();