(() => {
  if (window.__YHN_BATCH_V43_HOOK__) return;
  window.__YHN_BATCH_V43_HOOK__ = true;

  const TARGET = /\/lcms\/ca\/filter\/?$/i;
  let queryContext = null;

  function emit(detail) {
    window.postMessage({
      __YHN_BATCH_V43_HOOK__: true,
      type: "CA_FILTER_RESPONSE",
      detail
    }, "*");
  }

  window.addEventListener("message", ev => {
    const d = ev.data;
    if (!d?.__YHN_BATCH_V43_HOOK_CONTROL__) return;

    if (d.type === "SET_QUERY_CONTEXT") {
      const idno = String(d.idno || "").trim().toUpperCase();
      const itemToken = String(d.itemToken || "");

      queryContext = {
        idno,
        itemToken,
        setAt: Date.now()
      };

      window.postMessage({
        __YHN_BATCH_V43_HOOK__: true,
        type: "QUERY_CONTEXT_READY",
        itemToken
      }, "*");
      return;
    }

    if (d.type === "CLEAR_QUERY_CONTEXT") {
      const token = String(d.itemToken || "");
      if (!token || queryContext?.itemToken === token) {
        queryContext = null;
      }
    }
  });

  function process(meta, status, text) {
    try {
      if (!meta?.url || !TARGET.test(meta.url.pathname)) return;

      let json = null;
      try { json = JSON.parse(text || ""); } catch (_) { return; }

      const rows = Array.isArray(json?.rows) ? json.rows : [];
      const query = Object.fromEntries(meta.url.searchParams.entries());

      const ctx = queryContext;
      const expected = String(ctx?.idno || "").trim().toUpperCase();
      const actual = String(query.idno || "").trim().toUpperCase();
      const matched = !!ctx?.itemToken && !!expected && expected === actual;

      emit({
        status: Number(status || 0),
        matched,
        itemToken: ctx?.itemToken || "",
        total: Number(json?.total ?? rows.length),
        rows
      });

      if (matched) {
        queryContext = null;
      }
    } catch (_) {}
  }

  const nativeOpen = XMLHttpRequest.prototype.open;
  const nativeSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url) {
    try {
      this.__yhnBatchV41 = { url: new URL(url, location.href) };
    } catch (_) {
      this.__yhnBatchV41 = null;
    }
    return nativeOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function() {
    const meta = this.__yhnBatchV41;
    if (meta?.url?.origin === location.origin && TARGET.test(meta.url.pathname)) {
      this.addEventListener("loadend", function() {
        try { process(meta, this.status, this.responseText || ""); } catch (_) {}
      }, { once: true });
    }
    return nativeSend.apply(this, arguments);
  };

  const nativeFetch = window.fetch;
  window.fetch = async function(input, init = {}) {
    let meta = null;
    try {
      const raw = typeof input === "string" ? input : input?.url;
      meta = { url: new URL(raw, location.href) };
    } catch (_) {}

    const res = await nativeFetch.apply(this, arguments);

    if (meta?.url?.origin === location.origin && TARGET.test(meta.url.pathname)) {
      try {
        process(meta, res.status, await res.clone().text());
      } catch (_) {}
    }
    return res;
  };
})();