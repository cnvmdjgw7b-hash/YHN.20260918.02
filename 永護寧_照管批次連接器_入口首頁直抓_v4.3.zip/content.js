(() => {
  const isTop = window === window.top;
  const clean=s=>String(s||"").replace(/\s+/g," ").trim();

  function inject(name){
    const mount=()=>{
      try{
        const parent=document.head||document.documentElement;
        if(!parent){ setTimeout(mount,0); return; }
        const key=`yhn-${name.replace(/[^a-z0-9_-]/ig,"-")}`;
        if(document.querySelector(`script[data-yhn-inject="${key}"]`))return;
        const s=document.createElement("script");
        s.dataset.yhnInject=key;
        s.src=chrome.runtime.getURL(name);
        s.async=false;
        s.onload=()=>s.remove();
        s.onerror=()=>s.remove();
        parent.appendChild(s);
      }catch(_){}
    };
    mount();
  }
  inject("page_hook.js");

  async function fetchText(url){
    const r=await fetch(url,{credentials:"include",cache:"no-store"});
    const text=await r.text();
    if(!r.ok)throw new Error(`HTTP_${r.status}`);
    return text;
  }

  function recursiveFind(obj,keyRe,depth=0){
    if(depth>7||obj==null)return null;
    if(Array.isArray(obj)){
      for(const x of obj){const v=recursiveFind(x,keyRe,depth+1);if(v!=null)return v}
      return null;
    }
    if(typeof obj==="object"){
      for(const [k,v] of Object.entries(obj)){
        if(keyRe.test(k)&&(typeof v==="string"||typeof v==="number"))return v;
      }
      for(const v of Object.values(obj)){
        const x=recursiveFind(v,keyRe,depth+1);
        if(x!=null)return x;
      }
    }
    return null;
  }

  function allValues(obj,out=[],depth=0){
    if(depth>7||obj==null||out.length>2000)return out;
    if(typeof obj==="string"||typeof obj==="number"){out.push(String(obj));return out}
    if(Array.isArray(obj)){for(const x of obj)allValues(x,out,depth+1);return out}
    if(typeof obj==="object"){
      for(const [k,v] of Object.entries(obj)){out.push(k);allValues(v,out,depth+1)}
    }
    return out;
  }

  async function verifyId(id){
    if(!/^\d{8,12}$/.test(String(id||"")))return false;
    try{
      const h=await fetchText(`/lcms/ca/showCaseDetail/${encodeURIComponent(id)}`);
      return /照顧計畫|申報紀錄|異動通報/.test(h)&&!/查無資料|not found/i.test(h);
    }catch(_){return false}
  }

  async function deriveCa100Id(row){
    const direct=recursiveFind(row,/^ca100id$|^ca100.*id$/i);
    if(direct!=null&&await verifyId(direct))return String(direct);

    const vals=allValues(row),joined=vals.join(" ");
    const explicit=[];
    for(const re of [
      /showCaseDetail(?:\/|%2F)(\d{8,12})/ig,
      /CA100-LIST30(?:-2)?-(\d{8,12})/ig,
      /QD-LIST1(?:-2)?-(\d{8,12})/ig
    ]) for(const m of joined.matchAll(re))explicit.push(m[1]);

    for(const id of [...new Set(explicit)]){
      if(await verifyId(id))return id;
    }

    const nums=[...new Set(vals.flatMap(v=>String(v).match(/\b\d{8,12}\b/g)||[]))].slice(0,100);
    nums.sort((a,b)=>(a.length===10?0:1)-(b.length===10?0:1));

    for(const id of nums){
      if(await verifyId(id))return id;
    }
    return null;
  }

  function findSearchButton(){
    return [...document.querySelectorAll("button,input[type='button'],input[type='submit'],a")].find(el=>{
      const t=clean(el.textContent||el.value||"").replace(/\s+/g,"");
      return t==="查詢";
    })||null;
  }

  function clickableAround(el){
    if(!el)return null;
    if(el.matches?.("a,button,[onclick],[role='button'],[data-href],[data-url],[routerlink]"))return el;
    return el.querySelector?.("a,button,[onclick],[role='button'],[data-href],[data-url],[routerlink]")
      || el.closest?.("a,button,[onclick],[role='button'],[data-href],[data-url],[routerlink]")
      || null;
  }

  function findNavButton(){
    const all=[...document.querySelectorAll("a,button,[onclick],[role='button'],[data-href],[data-url],[routerlink],span,div,td,li")];
    const m=all.find(el=>{
      const t=clean(el.textContent||"").replace(/\s+/g,"");
      return t==="100-個案總查詢"||t==="100－個案總查詢"||t.includes("100－個案總查詢")||t.includes("100-個案總查詢");
    });
    return clickableAround(m)||m||null;
  }

  function findCaseMgmtButton(){
    const all=[...document.querySelectorAll("a,button,[onclick],[role='button'],[data-href],[data-url],[routerlink],div,section,article,li")];
    const candidates=all.filter(el=>{
      const t=clean(el.textContent||"").replace(/\s+/g,"");
      return t==="失能者個案管理" || t.includes("失能者個案管理");
    });

    for(const el of candidates){
      const clickable=clickableAround(el);
      if(clickable)return clickable;
    }
    return candidates[0]||null;
  }

  function activateNav(el){
    if(!el)return false;
    try{
      const raw=el.getAttribute?.("href")||el.getAttribute?.("data-href")||el.getAttribute?.("data-url")||el.getAttribute?.("routerlink");
      if(raw && raw!=="#" && !/^javascript:/i.test(raw)){
        const u=new URL(raw,location.href);
        if(u.origin===location.origin){ location.href=u.href; return true; }
      }
    }catch(_){}
    try{
      el.dispatchEvent(new MouseEvent("mousedown",{bubbles:true,cancelable:true,view:window}));
      el.dispatchEvent(new MouseEvent("mouseup",{bubbles:true,cancelable:true,view:window}));
      el.click?.();
      return true;
    }catch(_){return false}
  }

  let hookContextWaiter = null;

  function setHookQueryContext(idno, itemToken) {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        if (hookContextWaiter?.itemToken === itemToken) hookContextWaiter = null;
        reject(new Error("HOOK_CONTEXT_ACK_TIMEOUT"));
      }, 1500);

      hookContextWaiter = {
        itemToken,
        resolve: () => {
          clearTimeout(timeout);
          hookContextWaiter = null;
          resolve();
        }
      };

      window.postMessage({
        __YHN_BATCH_V43_HOOK_CONTROL__: true,
        type: "SET_QUERY_CONTEXT",
        idno,
        itemToken
      }, "*");
    });
  }

  // Each frame can answer probes, open CS100, and execute one official query.
  window.addEventListener("message",async ev=>{
    const d=ev.data;

    if(d?.__YHN_BATCH_V43_HOOK__&&d.type==="QUERY_CONTEXT_READY"){
      if(hookContextWaiter && d.itemToken===hookContextWaiter.itemToken){
        hookContextWaiter.resolve();
      }
      return;
    }

    if(d?.__YHN_BATCH_V43_DRIVER__&&d.type==="PROBE"){
      const hasIdno=!!document.querySelector('input[name="idno"]');
      const hasSearch=!!findSearchButton();
      const hasNav=!!findNavButton();
      const hasCaseMgmt=!!findCaseMgmtButton();
      window.top.postMessage({
        __YHN_BATCH_V43_DRIVER__:true,
        type:"CAPS",
        hasIdno,hasSearch,hasNav,hasCaseMgmt,
        path:location.pathname
      },"*");
      return;
    }

    if(d?.__YHN_BATCH_V43_DRIVER__&&d.type==="OPEN_CASE_MGMT"){
      const btn=findCaseMgmtButton();
      if(btn){
        activateNav(btn);
        window.top.postMessage({__YHN_BATCH_V43_DRIVER__:true,type:"CASE_MGMT_CLICKED"},"*");
      }
      return;
    }

    if(d?.__YHN_BATCH_V43_DRIVER__&&d.type==="OPEN_CS100"){
      const btn=findNavButton();
      if(btn){
        activateNav(btn);
        window.top.postMessage({__YHN_BATCH_V43_DRIVER__:true,type:"NAV_CLICKED"},"*");
      }
      return;
    }

    if(d?.__YHN_BATCH_V43_DRIVER__&&d.type==="QUERY_ONE"){
      const idno=String(d.idno||"").trim().toUpperCase().replace(/\s+/g,"");
      const itemToken=String(d.itemToken||"");
      if(!/^[A-Z0-9]{10}$/.test(idno)||!itemToken)return;

      const input=document.querySelector('input[name="idno"]');
      const btn=findSearchButton();
      if(!input||!btn)return;

      if(window.__YHN_BATCH_ACTIVE_TOKEN__)return;
      window.__YHN_BATCH_ACTIVE_TOKEN__=itemToken;

      window.top.postMessage({
        __YHN_BATCH_V43_DRIVER__:true,
        type:"CLAIMED",
        itemToken,
        path:location.pathname
      },"*");

      try{
        await setHookQueryContext(idno,itemToken);
      }catch(e){
        window.__YHN_BATCH_ACTIVE_TOKEN__=null;
        window.top.postMessage({
          __YHN_BATCH_V43_DRIVER__:true,
          type:"QUERY_ERROR",
          itemToken,
          error:String(e?.message||e)
        },"*");
        return;
      }

      for(const name of ["name","caseno","serialno"]){
        const el=document.querySelector(`[name="${name}"]`);
        if(el){
          el.value="";
          el.dispatchEvent(new Event("input",{bubbles:true}));
          el.dispatchEvent(new Event("change",{bubbles:true}));
        }
      }

      input.focus();
      input.value=idno;
      input.dispatchEvent(new Event("input",{bubbles:true}));
      input.dispatchEvent(new Event("change",{bubbles:true}));
      input.blur();

      await new Promise(r=>setTimeout(r,180));
      btn.click();

      setTimeout(()=>{
        if(window.__YHN_BATCH_ACTIVE_TOKEN__===itemToken){
          window.__YHN_BATCH_ACTIVE_TOKEN__=null;
          window.postMessage({
            __YHN_BATCH_V43_HOOK_CONTROL__:true,
            type:"CLEAR_QUERY_CONTEXT",
            itemToken
          },"*");
          window.top.postMessage({
            __YHN_BATCH_V43_DRIVER__:true,
            type:"QUERY_ERROR",
            itemToken,
            error:"OFFICIAL_QUERY_TIMEOUT"
          },"*");
        }
      },15000);
      return;
    }

    if(d?.__YHN_BATCH_V43_HOOK__&&d.type==="CA_FILTER_RESPONSE"){
      const detail=d.detail||{};
      const token=window.__YHN_BATCH_ACTIVE_TOKEN__;
      if(!token||!detail.matched||detail.itemToken!==token)return;

      const rows=Array.isArray(detail.rows)?detail.rows:[];
      window.top.postMessage({
        __YHN_BATCH_V43_DRIVER__:true,
        type:"QUERY_DEBUG",
        itemToken:token,
        rows:rows.length,
        total:Number(detail.total||0)
      },"*");

      if(rows.length!==1){
        window.__YHN_BATCH_ACTIVE_TOKEN__=null;
        window.top.postMessage({
          __YHN_BATCH_V43_DRIVER__:true,
          type:"QUERY_ERROR",
          itemToken:token,
          error:rows.length===0?"OFFICIAL_QUERY_NO_ROWS":"OFFICIAL_QUERY_MULTIPLE_ROWS"
        },"*");
        return;
      }

      const ca100id=await deriveCa100Id(rows[0]);
      window.__YHN_BATCH_ACTIVE_TOKEN__=null;

      if(!ca100id){
        window.top.postMessage({
          __YHN_BATCH_V43_DRIVER__:true,
          type:"QUERY_ERROR",
          itemToken:token,
          error:"CA100ID_NOT_FOUND_IN_OFFICIAL_ROW"
        },"*");
        return;
      }

      window.top.postMessage({
        __YHN_BATCH_V43_DRIVER__:true,
        type:"QUERY_SUCCESS",
        itemToken:token,
        ca100id
      },"*");
      return;
    }
  });

  if(!isTop)return;
  if(document.getElementById("yhn-batch-v43-root"))return;
  inject("page_bridge.js");

  const root=document.createElement("div");
  root.id="yhn-batch-v43-root";
  root.innerHTML=`
    <button id="fab">🐝</button>
    <div id="panel" class="hidden">
      <div class="head">
        <div><b>永護寧｜照管批次連接器 v4.3</b><small id="status">一次匯入，多案自動排隊</small></div>
        <button id="close">×</button>
      </div>

      <div class="note">
        登入後停在入口頁也可以。外掛會自動接續「失能者個案管理」→「100－個案總查詢」，
        再逐案用官方身分證查詢，讀照顧計畫、服務紀錄與個人額度。
        不需要你手動先進 CS100；單案失敗仍會繼續下一案。
      </div>

      <label>查詢月份<input id="month" type="month"></label>

      <label>批次個案
        <textarea id="batchInput" rows="5" placeholder="可貼：姓名 身分證&#10;例如：王○○ A123456789&#10;每行一案；只要行內有 1 個英文字母 + 9 碼數字即可"></textarea>
      </label>

      <input id="fileInput" type="file" accept=".txt,.csv,text/plain,text/csv" hidden>
      <div class="actions">
        <button id="pickFile" class="secondary">匯入 TXT / CSV</button>
        <button id="parse" class="secondary">整理清單</button>
      </div>

      <div id="summary" class="summary">尚未建立批次清單。</div>

      <button id="start">開始批次讀取</button>
      <button id="stop" class="danger" disabled>停止</button>

      <div class="actions">
        <button id="exportCsv" class="secondary" disabled>匯出 CSV</button>
        <button id="exportJson" class="secondary" disabled>匯出 JSON</button>
      </div>

      <div id="progress"></div>
      <div id="rows"></div>
    </div>`;
  document.documentElement.appendChild(root);

  const panel=root.querySelector("#panel"),status=root.querySelector("#status"),
        progress=root.querySelector("#progress"),summary=root.querySelector("#summary"),
        rowsBox=root.querySelector("#rows"),monthEl=root.querySelector("#month"),
        batchInput=root.querySelector("#batchInput"),fileInput=root.querySelector("#fileInput"),
        pickFile=root.querySelector("#pickFile"),parseBtn=root.querySelector("#parse"),
        startBtn=root.querySelector("#start"),stopBtn=root.querySelector("#stop"),
        exportCsvBtn=root.querySelector("#exportCsv"),exportJsonBtn=root.querySelector("#exportJson");

  const now=new Date();
  monthEl.value=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}`;

  root.querySelector("#fab").onclick=()=>panel.classList.toggle("hidden");
  root.querySelector("#close").onclick=()=>panel.classList.add("hidden");

  const esc=v=>String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;");
  const maskId=s=>String(s||"").replace(/^(.).{6}(...$)/,"$1******$2");

  let queue=[],running=false,stopRequested=false,currentIndex=-1,currentToken=null,currentReq=null,currentCaseReq=null;
  let caps={hasIdno:false,hasNav:false,hasCaseMgmt:false};
  let claimReceived=false;
  let claimTimer=null;

  function broadcast(msg){
    const seen=new Set();
    function walk(w){
      if(!w||seen.has(w))return;
      seen.add(w);
      try{w.postMessage(msg,"*")}catch(_){}
      let n=0;
      try{n=w.frames.length}catch(_){}
      for(let i=0;i<n;i++){try{walk(w.frames[i])}catch(_){}}
    }
    walk(window);
  }

  const SESSION_KEY="YHN_BATCH_V43_AUTORUN";

  function saveAutoResume(){
    try{
      sessionStorage.setItem(SESSION_KEY,JSON.stringify({
        at:Date.now(),
        month:monthEl.value,
        batchText:batchInput.value,
        autoResume:true
      }));
    }catch(_){}
  }

  function clearAutoResume(){
    try{sessionStorage.removeItem(SESSION_KEY)}catch(_){}
  }

  function loadAutoResume(){
    try{
      const raw=sessionStorage.getItem(SESSION_KEY);
      if(!raw)return null;
      const state=JSON.parse(raw);
      if(!state?.autoResume || Date.now()-Number(state.at||0)>120000){
        clearAutoResume();
        return null;
      }
      return state;
    }catch(_){
      clearAutoResume();
      return null;
    }
  }

  function parseList(text){
    const lines=String(text||"").split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
    const out=[],seen=new Set();

    for(const line of lines){
      const matches=line.toUpperCase().match(/\b[A-Z][0-9]{9}\b/g)||[];
      for(const idno of matches){
        if(seen.has(idno))continue;
        seen.add(idno);

        let label=line.replace(idno,"").replace(/[,\t;|]+/g," ").replace(/\s+/g," ").trim();
        if(!label)label=`個案 ${out.length+1}`;

        out.push({
          idno,
          label:label.slice(0,40),
          status:"待處理",
          error:null,
          ca100id:null,
          data:null
        });
      }
    }
    return out;
  }

  function render(){
    const done=queue.filter(x=>x.status==="完成").length;
    const failed=queue.filter(x=>x.status==="失敗").length;
    const active=queue.filter(x=>x.status==="查詢中"||x.status==="讀取中").length;

    summary.innerHTML=queue.length
      ? `共 <b>${queue.length}</b> 案｜完成 ${done}｜失敗 ${failed}${active?`｜處理中 ${active}`:""}`
      : "尚未建立批次清單。";

    rowsBox.innerHTML=queue.map((x,i)=>`
      <div class="caseRow">
        <div>
          <b>${i+1}. ${esc(x.label)}</b>
          <small>${esc(maskId(x.idno))}</small>
        </div>
        <span class="badge ${x.status==="完成"?"okb":x.status==="失敗"?"errb":x.status==="查詢中"||x.status==="讀取中"?"runb":""}">${esc(x.status)}</span>
      </div>
    `).join("");

    const hasResults=queue.some(x=>x.status==="完成"||x.status==="失敗");
    exportCsvBtn.disabled=!hasResults;
    exportJsonBtn.disabled=!hasResults;
  }

  function buildQueue(){
    queue=parseList(batchInput.value);
    render();
    status.textContent=queue.length?`已建立 ${queue.length} 案批次`:"沒有找到有效身分證";
  }

  pickFile.onclick=()=>fileInput.click();
  fileInput.onchange=async()=>{
    const f=fileInput.files?.[0];
    if(!f)return;
    const text=await f.text();
    batchInput.value=text;
    buildQueue();
  };
  parseBtn.onclick=buildQueue;

  async function directFindCase(item,index){
    currentCaseReq=`case-direct-${Date.now()}-${index}-${Math.random().toString(16).slice(2)}`;
    const reqId=currentCaseReq;

    const p=new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>{
        if(currentCaseReq===reqId){
          window.__YHN_BATCH_DIRECT_RESOLVE__=null;
          window.__YHN_BATCH_DIRECT_REJECT__=null;
          reject(new Error("DIRECT_CS100_QUERY_TIMEOUT"));
        }
      },6500);

      window.__YHN_BATCH_DIRECT_RESOLVE__=(value)=>{
        clearTimeout(timer);
        resolve(value);
      };
      window.__YHN_BATCH_DIRECT_REJECT__=(err)=>{
        clearTimeout(timer);
        reject(err);
      };
    });

    window.postMessage({
      __YHN_BATCH_V43_BRIDGE__:true,
      type:"FIND_CASE",
      requestId:reqId,
      payload:{idno:item.idno}
    },"*");

    return await p;
  }

  async function ensureOfficialCs100(){
    const started=Date.now();
    let caseMgmtClicked=false;
    let cs100Clicked=false;

    while(Date.now()-started<14000){
      caps={hasIdno:false,hasNav:false,hasCaseMgmt:false};
      broadcast({__YHN_BATCH_V43_DRIVER__:true,type:"PROBE"});
      await new Promise(r=>setTimeout(r,350));

      if(caps.hasIdno)return true;

      if(caps.hasNav && !cs100Clicked){
        cs100Clicked=true;
        progress.textContent="已進入失能者個案管理，正在自動開啟 100－個案總查詢…";
        broadcast({__YHN_BATCH_V43_DRIVER__:true,type:"OPEN_CS100"});
        await new Promise(r=>setTimeout(r,1100));
        continue;
      }

      if(caps.hasCaseMgmt && !caseMgmtClicked){
        caseMgmtClicked=true;
        progress.textContent="已登入，正在自動進入失能者個案管理…";
        saveAutoResume();
        broadcast({__YHN_BATCH_V43_DRIVER__:true,type:"OPEN_CASE_MGMT"});
        await new Promise(r=>setTimeout(r,1600));
        continue;
      }

      await new Promise(r=>setTimeout(r,450));
    }

    return false;
  }

  function nextPendingIndex(){
    for(let i=currentIndex+1;i<queue.length;i++){
      if(queue[i].status==="待處理")return i;
    }
    return -1;
  }

  async function queryOne(item,index){
    item.status="查詢中";item.error=null;render();
    progress.textContent=`${index+1}/${queue.length}｜${item.label}：入口頁直接查詢官方 CS100…`;

    let ca100id=null;
    let directError=null;

    try{
      const direct=await directFindCase(item,index);
      ca100id=direct?.ca100id||null;
    }catch(e){
      directError=String(e?.message||e);
    }

    if(!ca100id){
      progress.textContent=`${index+1}/${queue.length}｜${item.label}：入口直查未完成，改走 100－個案總查詢頁面…`;
      const ready=await ensureOfficialCs100();
      if(!ready)throw new Error(`CS100_ENTRY_AND_DIRECT_QUERY_FAILED${directError?`｜${directError}`:""}`);

      currentToken=`case-${Date.now()}-${index}-${Math.random().toString(16).slice(2)}`;
      claimReceived=false;

      const queryPromise=new Promise((resolve,reject)=>{
        window.__YHN_BATCH_QUERY_RESOLVE__=resolve;
        window.__YHN_BATCH_QUERY_REJECT__=reject;
      });

      broadcast({
        __YHN_BATCH_V43_DRIVER__:true,
        type:"QUERY_ONE",
        idno:item.idno,
        itemToken:currentToken
      });

      claimTimer=setTimeout(()=>{
        if(!claimReceived){
          try{window.__YHN_BATCH_QUERY_REJECT__?.(new Error("CS100_QUERY_DRIVER_NOT_CLAIMED"))}catch(_){}
        }
      },3000);

      ca100id=await queryPromise;
    }

    item.ca100id=ca100id;
    item.status="讀取中";render();

    progress.textContent=`${index+1}/${queue.length}｜${item.label}：照顧計畫／服務紀錄／額度讀取中…`;

    currentReq=`data-${Date.now()}-${index}-${Math.random().toString(16).slice(2)}`;
    const dataPromise=new Promise((resolve,reject)=>{
      window.__YHN_BATCH_DATA_RESOLVE__=resolve;
      window.__YHN_BATCH_DATA_REJECT__=reject;
    });

    window.postMessage({
      __YHN_BATCH_V43_BRIDGE__:true,
      type:"FETCH_DATA",
      requestId:currentReq,
      payload:{ca100id,month:monthEl.value}
    },"*");

    const data=await dataPromise;
    item.data=data;
    item.status="完成";
    render();
  }

  async function runBatch(){
    if(!queue.length)buildQueue();
    if(!queue.length){
      status.textContent="請先貼上或匯入個案清單";
      return;
    }

    running=true;stopRequested=false;currentIndex=-1;
    startBtn.disabled=true;stopBtn.disabled=false;
    status.textContent="批次執行中";

    while(!stopRequested){
      const idx=nextPendingIndex();
      if(idx<0)break;
      currentIndex=idx;

      try{
        await queryOne(queue[idx],idx);
      }catch(e){
        queue[idx].status="失敗";
        queue[idx].error=String(e?.message||e);
        render();
      }

      await new Promise(r=>setTimeout(r,250));
    }

    running=false;
    clearAutoResume();
    startBtn.disabled=false;stopBtn.disabled=true;
    progress.textContent="";
    const done=queue.filter(x=>x.status==="完成").length;
    const failed=queue.filter(x=>x.status==="失敗").length;
    status.textContent=stopRequested?`已停止｜完成 ${done}｜失敗 ${failed}`:`批次完成｜成功 ${done}｜失敗 ${failed}`;
  }

  startBtn.onclick=runBatch;
  stopBtn.onclick=()=>{
    stopRequested=true;
    clearAutoResume();
    status.textContent="正在停止…";
  };

  function csvEscape(v){
    const s=String(v??"");
    return /[",\n]/.test(s)?`"${s.replaceAll('"','""')}"`:s;
  }

  function download(name,text,type){
    const blob=new Blob([text],{type});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url;a.download=name;document.documentElement.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  }

  exportCsvBtn.onclick=()=>{
    const lines=[[
      "序號","標籤","身分證","狀態","錯誤","月份","服務紀錄筆數","服務碼統計","核定服務","額度查詢"
    ].join(",")];

    queue.forEach((x,i)=>{
      const codes=x.data?.serviceRecords?.byCode||{};
      const codeText=Object.entries(codes).map(([k,v])=>`${k}:${v}`).join("；");
      const plan=(x.data?.plan?.services||[]).map(s=>`${s.code}:${s.approvedQty}`).join("；");
      const balance=x.data?.balance?.ok?"成功":"未完成";

      lines.push([
        i+1,x.label,x.idno,x.status,x.error||"",monthEl.value,
        x.data?.serviceRecords?.rows??"",codeText,plan,balance
      ].map(csvEscape).join(","));
    });

    download(`永護寧_照管批次結果_${monthEl.value}.csv`,"\ufeff"+lines.join("\n"),"text/csv;charset=utf-8");
  };

  exportJsonBtn.onclick=()=>{
    download(
      `永護寧_照管批次結果_${monthEl.value}.json`,
      JSON.stringify({
        generatedAt:new Date().toISOString(),
        month:monthEl.value,
        results:queue
      },null,2),
      "application/json;charset=utf-8"
    );
  };

  window.addEventListener("message",ev=>{
    const d=ev.data;

    if(d?.__YHN_BATCH_V43_DRIVER__){
      if(d.type==="CAPS"){
        if(d.hasIdno&&d.hasSearch)caps.hasIdno=true;
        if(d.hasNav)caps.hasNav=true;
        if(d.hasCaseMgmt)caps.hasCaseMgmt=true;
        return;
      }

      if(d.type==="CASE_MGMT_CLICKED"){
        status.textContent="正在進入失能者個案管理…";
        return;
      }

      if(d.type==="NAV_CLICKED"){
        status.textContent="正在開啟 100－個案總查詢…";
        return;
      }

      if(d.type==="CLAIMED"&&d.itemToken===currentToken){
        claimReceived=true;
        if(claimTimer)clearTimeout(claimTimer);
        return;
      }

      if(d.type==="QUERY_ERROR"&&d.itemToken===currentToken){
        if(claimTimer)clearTimeout(claimTimer);
        const rej=window.__YHN_BATCH_QUERY_REJECT__;
        window.__YHN_BATCH_QUERY_RESOLVE__=null;
        window.__YHN_BATCH_QUERY_REJECT__=null;
        rej?.(new Error(d.error||"QUERY_ERROR"));
        return;
      }

      if(d.type==="QUERY_SUCCESS"&&d.itemToken===currentToken){
        if(claimTimer)clearTimeout(claimTimer);
        const res=window.__YHN_BATCH_QUERY_RESOLVE__;
        window.__YHN_BATCH_QUERY_RESOLVE__=null;
        window.__YHN_BATCH_QUERY_REJECT__=null;
        res?.(d.ca100id);
        return;
      }
    }

    if(d?.__YHN_BATCH_V43_BRIDGE__&&d.requestId===currentCaseReq){
      if(d.stage==="caseError"){
        const rej=window.__YHN_BATCH_DIRECT_REJECT__;
        window.__YHN_BATCH_DIRECT_RESOLVE__=null;
        window.__YHN_BATCH_DIRECT_REJECT__=null;
        rej?.(new Error(d.payload?.message||"DIRECT_CS100_QUERY_FAILED"));
        return;
      }

      if(d.stage==="caseDone"){
        const res=window.__YHN_BATCH_DIRECT_RESOLVE__;
        window.__YHN_BATCH_DIRECT_RESOLVE__=null;
        window.__YHN_BATCH_DIRECT_REJECT__=null;
        res?.(d.payload||{});
        return;
      }
    }

    if(d?.__YHN_BATCH_V43_BRIDGE__&&d.requestId===currentReq){
      if(d.stage==="progress"){
        progress.textContent=`${currentIndex+1}/${queue.length}｜${queue[currentIndex]?.label||""}：${d.payload?.text||"讀取中…"}`;
        return;
      }

      if(d.stage==="error"){
        const rej=window.__YHN_BATCH_DATA_REJECT__;
        window.__YHN_BATCH_DATA_RESOLVE__=null;
        window.__YHN_BATCH_DATA_REJECT__=null;
        rej?.(new Error(d.payload?.message||"DATA_ERROR"));
        return;
      }

      if(d.stage==="done"){
        const res=window.__YHN_BATCH_DATA_RESOLVE__;
        window.__YHN_BATCH_DATA_RESOLVE__=null;
        window.__YHN_BATCH_DATA_REJECT__=null;
        res?.(d.payload||{});
      }
    }
  });

  const resumeState=loadAutoResume();
  if(resumeState){
    if(resumeState.month)monthEl.value=resumeState.month;
    if(resumeState.batchText)batchInput.value=resumeState.batchText;
    buildQueue();
    status.textContent="已接續登入後流程，準備自動批次讀取…";
    setTimeout(()=>{
      if(!running && queue.length){
        clearAutoResume();
        runBatch();
      }
    },700);
  }

  render();
})();